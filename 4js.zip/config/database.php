<?php
// Database configuration
define('DB_HOST', 'localhost');
define('DB_NAME', 'job_order_system');
define('DB_USER', 'root');
define('DB_PASS', '');

// Error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);
?> 